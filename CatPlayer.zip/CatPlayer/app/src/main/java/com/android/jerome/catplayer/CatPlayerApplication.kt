package com.android.jerome.catplayer

import android.app.Application
import android.content.Context

class CatPlayerApplication : Application() {
    companion object {
        var sContext: Context? = null
    }

    override fun onCreate() {
        super.onCreate()
        sContext = applicationContext
    }
}