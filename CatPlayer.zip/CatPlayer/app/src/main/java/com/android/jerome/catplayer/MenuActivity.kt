package com.android.jerome.catplayer

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.android.jerome.catplayer.movieDB.ui.activities.MovieDBRecycleListActivity
import com.android.jerome.catplayer.videoplayer.activities.PlayerListActivity
import kotlinx.android.synthetic.main.activity_menu.*

class MenuActivity : AppCompatActivity(), View.OnClickListener {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)

        //Set listeners to each button
        menu_myvideos.setOnClickListener(this)
        menu_moviedb.setOnClickListener(this)
        menu_credits.setOnClickListener(this)
    }

    override fun onClick(v: View?) {
        when(v?.id){
            //Go to "My Videos" activity
            R.id.menu_myvideos -> {
                val intent = Intent(this, PlayerListActivity::class.java)
                startActivity(intent)
            }

            //Go to "MovieDB repertory" activity
            R.id.menu_moviedb -> {
                val intent = Intent(this, MovieDBRecycleListActivity::class.java)
                startActivity(intent)
            }

            //Go to "Credits" activity
            R.id.menu_credits -> {
                val intent = Intent(this, CreditsActivity::class.java)
                startActivity(intent)
            }
        }
    }

}
