package com.android.jerome.catplayer

import android.support.v4.app.DialogFragment
import android.os.Bundle
import android.support.v4.app.FragmentManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import kotlinx.android.synthetic.main.search_fragment.*


class SearchDialogFragment : DialogFragment(), View.OnClickListener {
    private var isvideoplayer: Boolean = false

    fun switchToVideoPlayer(){
        isvideoplayer = true
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.search_txt_button -> {
                if(txt_research.text != null && txt_research.text.toString() != "") {
                    val act = activity as SearchListener
                    val searchMode: String = if (tv_radio_button.isChecked) "tv" else "movie"
                    if(isvideoplayer){
                        act.researchQuery(txt_research.text.toString(), "")
                    }else {
                        act.researchQuery(txt_research.text.toString(), searchMode)
                    }
                    dismiss()
                }
            }
        }
    }

    fun newInstance(title: String): SearchDialogFragment {

        val frag = SearchDialogFragment()
        val args = Bundle()
        args.putString("search", title)
        frag.arguments = args
        return frag

    }

    override fun onStart() {
        super.onStart()

        dialog.window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT)

    }
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        var infl =  inflater?.inflate(R.layout.search_fragment, container) ?: inflater?.let { super.onCreateView(it, container, savedInstanceState) }!!
        return infl
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        view?.let { super.onViewCreated(it, savedInstanceState) }
        if(isvideoplayer) radiogroup?.visibility = View.INVISIBLE

        val title = arguments?.getString("search", "")
        dialog.setTitle(title)

        txt_research.requestFocus()
        dialog.window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE)

        search_txt_button.setOnClickListener(this)

    }
}