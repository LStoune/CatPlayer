package com.android.jerome.catplayer

interface SearchListener {
    fun researchQuery(query:String,tv_or_movie:String,page:Int = 1)
}