package com.android.jerome.catplayer.movieDB.async

import android.os.AsyncTask
import android.util.Log
import com.android.jerome.catplayer.CatPlayerApplication
import com.android.jerome.catplayer.movieDB.model.Movie
import com.android.jerome.catplayer.movieDB.ui.database.DatabaseHelper
import com.android.jerome.catplayer.movieDB.ui.utils.GetFavoritesListener

class AddMovieAsyncTask(var listener: GetFavoritesListener) : AsyncTask<Movie, Void, Void>() {

    override fun doInBackground(vararg params: Movie): Void? {
        Log.d("CATPLAYER", CatPlayerApplication.sContext.toString())
        CatPlayerApplication.sContext?.let { Log.d("CATPLAYER","OUII!!!");DatabaseHelper.getInstance(it).getMovieDao().insert(params[0]) }
        return null
    }

    override fun onPostExecute(result: Void?) {
        super.onPostExecute(result)
        listener.changeFavorite()
    }
}