package com.android.jerome.catplayer.movieDB.async

import android.os.AsyncTask
import android.util.Log
import com.android.jerome.catplayer.CatPlayerApplication
import com.android.jerome.catplayer.movieDB.ui.database.DatabaseHelper
import com.android.jerome.catplayer.movieDB.ui.utils.GetFavoritesListener

class DeleteMovieAsyncTask(var listener: GetFavoritesListener) : AsyncTask<Int, Void, Void>() {

    override fun doInBackground(vararg params: Int?): Void? {
        Log.d("CATPLAYER", CatPlayerApplication.sContext.toString())
        CatPlayerApplication.sContext?.let { Log.d("CATPLAYER","OUII!!!");params[0]?.let { it1 ->
            DatabaseHelper.getInstance(it).getMovieDao().delete(
                it1
            )
        } }
        return null
    }

    override fun onPostExecute(result: Void?) {
        super.onPostExecute(result)
        listener.changeFavorite()
    }
}