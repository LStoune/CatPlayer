package com.android.jerome.catplayer.movieDB.async

import android.os.AsyncTask
import com.android.jerome.catplayer.CatPlayerApplication
import com.android.jerome.catplayer.movieDB.ui.database.DatabaseHelper
import com.android.jerome.catplayer.movieDB.ui.utils.GetFavoritesListener

class GetIdsAsyncTask(var listener: GetFavoritesListener) : AsyncTask<Void, Void, List<Int>>() {

    override fun doInBackground(vararg params: Void?): List<Int> {
        return CatPlayerApplication.sContext?.let { DatabaseHelper.getInstance(it).getMovieDao().getIds() } ?: ArrayList()
    }

    override fun onPostExecute(result: List<Int>) {
        super.onPostExecute(result)
        listener.setOrNotFavorite(result as ArrayList<Int>)
    }
}