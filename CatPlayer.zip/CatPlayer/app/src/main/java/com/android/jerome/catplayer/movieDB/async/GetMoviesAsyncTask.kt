package com.android.jerome.catplayer.movieDB.async

import android.content.Context
import android.os.AsyncTask
import com.android.jerome.catplayer.CatPlayerApplication
import com.android.jerome.catplayer.movieDB.model.Movie
import com.android.jerome.catplayer.movieDB.ui.utils.MovieChangeListener
import com.android.jerome.catplayer.movieDB.ui.database.DatabaseHelper

class GetMoviesAsyncTask(var context:Context,var listener: MovieChangeListener) : AsyncTask<Void, Void, List<Movie>>() {

    override fun doInBackground(vararg params: Void?): List<Movie> {
        return CatPlayerApplication.sContext?.let { DatabaseHelper.getInstance(it).getMovieDao().getAll() } ?: ArrayList()
    }

    override fun onPostExecute(result: List<Movie>) {
        super.onPostExecute(result)
        listener.onMovieRetrieved(result as ArrayList<Movie>)
    }
}