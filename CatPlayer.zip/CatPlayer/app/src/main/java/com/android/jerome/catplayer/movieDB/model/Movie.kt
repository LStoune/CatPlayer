package com.android.jerome.catplayer.movieDB.model

import android.arch.persistence.room.ColumnInfo
import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey
import android.arch.persistence.room.TypeConverter
import android.support.annotation.NonNull
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName
import java.io.Serializable
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken



@Entity
data class Movie(
    @NonNull
    @PrimaryKey
    @ColumnInfo(name = "id")
    @SerializedName("id")
    @Expose
    var id: Int?,


    @ColumnInfo(name = "original_title")
    @SerializedName("original_title",alternate = ["original_name"])
    @Expose
    var originalTitle: String?,

    @ColumnInfo(name = "original_language")
    @SerializedName("original_language")
    @Expose
    var originalLanguage: String?,

    @ColumnInfo(name = "origin_country")
    @SerializedName("origin_country")
    @Expose
    var originCountry: ArrayList<String>? = ArrayList(),

    @ColumnInfo(name = "title")
    @SerializedName("title",alternate = ["name"])
    @Expose
    var title: String?,

    @ColumnInfo(name = "release_date")
    @SerializedName("release_date",alternate = ["first_air_date"])
    @Expose
    var releaseDate: String?,

    @ColumnInfo(name = "genre_ids")
    @SerializedName("genre_ids")
    @Expose
    var genreIds:ArrayList<Int> = ArrayList(),

    @ColumnInfo(name = "overview")
    @SerializedName("overview")
    @Expose
    var overview: String?,


    @ColumnInfo(name = "poster_path")
    @SerializedName("poster_path")
    @Expose
    var posterPath: String?,

    @ColumnInfo(name = "backdrop_path")
    @SerializedName("backdrop_path")
    @Expose
    var backdropPath: String?,


    @ColumnInfo(name = "adult")
    @SerializedName("adult")
    @Expose
    var adult: Boolean?,

    @ColumnInfo(name = "video")
    @SerializedName("video")
    @Expose
    var video: Boolean?,


    @ColumnInfo(name = "popularity")
    @SerializedName("popularity")
    @Expose
    var popularity: Double?,

    @ColumnInfo(name = "vote_count")
    @SerializedName("vote_count")
    @Expose
    var voteCount: Int?,

    @ColumnInfo(name = "vote_average")
    @SerializedName("vote_average")
    @Expose
    var voteAverage: Double?) : Serializable {
    override fun toString(): String {
        return overview!!
    }
}

class ConvertersInt {
    @TypeConverter
    fun fromString(value: String): ArrayList<Int> {
        val listType = object : TypeToken<ArrayList<Int>>() {

        }.type
        return Gson().fromJson(value, listType)
    }

    @TypeConverter
    fun fromArrayList(list: ArrayList<Int>): String {
        val gson = Gson()
        return gson.toJson(list)
    }
}

class ConvertersString {
    @TypeConverter
    fun fromString(value: String): ArrayList<String>? {
        val listType = object : TypeToken<ArrayList<String>?>() {

        }.type
        return Gson().fromJson(value, listType)
    }

    @TypeConverter
    fun fromArrayList(list: ArrayList<String>?): String {
        val gson = Gson()
        return gson.toJson(list)
    }
}