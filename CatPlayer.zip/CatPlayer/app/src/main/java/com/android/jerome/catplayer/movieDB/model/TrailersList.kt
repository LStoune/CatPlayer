package com.android.jerome.catplayer.movieDB.model

import com.android.jerome.catplayer.movieDB.model.Trailer
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName



class TrailersList {
    @SerializedName("id")
    @Expose
    val id: Int? = null

    @SerializedName("results")
    @Expose
    val trailers: ArrayList<Trailer> = ArrayList()
}