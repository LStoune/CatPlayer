package com.android.jerome.catplayer.movieDB.network

import android.content.Context
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.Retrofit.*
import retrofit2.converter.gson.GsonConverterFactory

class MovieAPI {
    companion object {
        var retrofit: Retrofit? = null
        val URL = "https://api.themoviedb.org/3/"

        fun createRetrofit(): MovieDBService? {
            if (retrofit == null) {
                val okhttp = OkHttpClient.Builder()
                    .addInterceptor(HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY))
                    .build()
                retrofit = Builder()
                    .addConverterFactory(GsonConverterFactory.create())
                    .client(okhttp)
                    .baseUrl(URL)
                    .build()
            }
            return retrofit?.create(MovieDBService::class.java)
        }
    }
}