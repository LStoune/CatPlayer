package com.android.jerome.catplayer.movieDB.network

import com.android.jerome.catplayer.movieDB.model.Genres
import com.android.jerome.catplayer.movieDB.model.ResultsMovies
import com.android.jerome.catplayer.movieDB.model.TrailersList
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface MovieDBService {
    @GET("{selection1}/{selection2}")
    fun getMovies(
        @Path("selection1") selection1: String,
        @Path("selection2") selection2: String,
        @Query("api_key")  key : String,
        @Query("language") lang : String,
        @Query("page") page : Int
    ): Call<ResultsMovies>

    @GET("search/{tv_or_movie}")
    fun getResearch(
        @Path("tv_or_movie") tv_or_movie:String,
        @Query("api_key")  key : String,
        @Query("language") lang : String,
        @Query("query") query : String,
        @Query("page") page : Int
    ): Call<ResultsMovies>

    @GET("movie/{id}/videos")
    fun getTrailers(
        @Path("id") id : Int,
        @Query("api_key") key : String,
        @Query("language") lang : String
    ): Call<TrailersList>

    @GET("genre/movie/list")
    fun getGenres(
        @Query("api_key") key : String,
        @Query("language") lang : String
    ): Call<Genres>

}