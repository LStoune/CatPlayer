package com.android.jerome.catplayer.movieDB.ui.activities

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.bumptech.glide.Glide

import kotlinx.android.synthetic.main.activity_movie.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import android.content.Intent
import android.net.Uri
import android.view.*
import com.android.jerome.catplayer.R
import com.android.jerome.catplayer.movieDB.async.AddMovieAsyncTask
import com.android.jerome.catplayer.movieDB.async.DeleteMovieAsyncTask
import com.android.jerome.catplayer.movieDB.async.GetIdsAsyncTask
import com.android.jerome.catplayer.movieDB.model.Genres
import com.android.jerome.catplayer.movieDB.model.Movie
import com.android.jerome.catplayer.movieDB.model.Trailer
import com.android.jerome.catplayer.movieDB.model.TrailersList
import com.android.jerome.catplayer.movieDB.network.MovieAPI
import com.android.jerome.catplayer.movieDB.network.MovieDBService
import com.android.jerome.catplayer.movieDB.ui.adapter.MovieCellsAdapter
import com.android.jerome.catplayer.movieDB.ui.adapter.TrailersAdapter
import com.android.jerome.catplayer.movieDB.ui.utils.GetFavoritesListener

class MovieActivity : AppCompatActivity(),View.OnClickListener,
    GetFavoritesListener {
    override fun changeFavorite() {
        var asynct = GetIdsAsyncTask(this)
        asynct.execute()
    }

    private var movie: Movie? = null
    private var movieTrailersService: MovieDBService? = null
    private var trailersAdapter: TrailersAdapter? = null
    private var listTrailers:ArrayList<Trailer> = ArrayList()
    private var isFavorite:Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_movie)

        setSupportActionBar(toolbar_movie)
        movieTrailersService = MovieAPI.createRetrofit()
        movie = intent.extras.get("MOVIE_EXTRA") as Movie

        loadGenres()

        supportActionBar?.title = movie?.title
        supportActionBar?.subtitle = movie?.originalTitle
        supportActionBar?.elevation = 4.0F

        Log.d("TESTTEST",movie.toString())

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)
        supportActionBar?.setDisplayUseLogoEnabled(false)

        movie_title.text = movie?.title
        movie_originaltitle.text = movie?.originalTitle
        movie_originallanguage.text = movie?.originalLanguage
        movie_releasedate.text = movie?.releaseDate

        Glide.with(this)
            .load(MovieCellsAdapter.URL_MOVIEDB_IMAGES + movie?.posterPath)
            .centerCrop()
            .placeholder(R.drawable.poster_empty)
            .into(movie_poster)
        movie_desc.text = movie?.overview
        movie_moyenne.text = movie?.voteAverage.toString()+"/10"

        loadTrailers()
        favori_button.setOnClickListener(this)

        changeFavorite()
    }

    fun loadGenres(){
        movieTrailersService?.getGenres(getString(R.string.apikey),getString(R.string.lang))
            ?.enqueue(object : Callback<Genres> {
                override fun onResponse(call: Call<Genres>, response: Response<Genres>) {
                    Log.d("PLAYERCAT", "Success")
                    Log.d("PLAYERCAT", response.code().toString())
                    Log.d("PLAYERCAT", response.raw().request().url().toString())

                    if (response == null) Log.d("PLAYERCAT", "null") else Log.d("PLAYERCAT", "pas null")
                    if (response.isSuccessful) Log.d("PLAYERCAT", "successful") else Log.d("PLAYERCAT", "pas successful")

                    if(response != null && response.isSuccessful) {
                        val result = response.body().genres
                        var genres = ""
                        for(item in result){
                            if(movie?.genreIds?.contains(item.id) == true){
                                genres += item.name + " "
                            }
                        }
                        movie_genre.text = genres
                        Log.d("PLAYERCAT", "Genres loaded")
                    }
                }

                override fun onFailure(call: Call<Genres>, t: Throwable) {
                    Log.d("PLAYERCAT","Failure")
                    t.printStackTrace()
                }
            })
    }

    override fun setOrNotFavorite(ids_favorites: List<Int>) {
        Log.d("FAVORI","favori")
        Log.d("FAVORI",ids_favorites.toString())
        if(movie != null && ids_favorites.contains(movie?.id)){
            favori_button.setImageDrawable(getDrawable(R.drawable.isfavori))
            isFavorite = true
        }else{
            favori_button.setImageDrawable(getDrawable(R.drawable.favori))
            isFavorite = false
        }

    }

    override fun onClick(item: View){
        when (item.id){
            R.id.favori_button -> {
                Log.d("CATPLAYER","favori")
                if(!isFavorite) {
                    addToFavorite()
                }else{
                    deleteFromFavorite()
                }
            }
        }
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when(item?.itemId) {
            android.R.id.home -> {
                finish()
                return true
            }
        }
        return false
    }

    fun loadTrailers(){
        trailersAdapter = TrailersAdapter(this, null)
        movie?.id?.let {
            movieTrailersService?.getTrailers(it, getString(R.string.apikey),getString(
                R.string.lang
            ))
                ?.enqueue(object : Callback<TrailersList> {
                    override fun onResponse(call: Call<TrailersList>, response: Response<TrailersList>) {
                        Log.d("PLAYERCAT", "Success")
                        Log.d("PLAYERCAT", response.code().toString())
                        Log.d("PLAYERCAT", response.raw().request().url().toString())

                        if (response == null) Log.d("PLAYERCAT", "null") else Log.d("PLAYERCAT", "pas null")
                        if (response.isSuccessful) Log.d("PLAYERCAT", "successful") else Log.d("PLAYERCAT", "pas successful")

                        if(response != null && response.isSuccessful) {
                            listTrailers = response.body().trailers
                            Log.d("PLAYERCAT", listTrailers.size.toString())
                            trailersAdapter?.setTrailers(listTrailers)
                            trailerslist.adapter = trailersAdapter

                            var desiredWidth = View.MeasureSpec.makeMeasureSpec(trailerslist.width,
                            View.MeasureSpec.UNSPECIFIED);
                            var totalHeight = 0
                            for (i in 0..(trailersAdapter?.count?.minus(1) ?: 0)) {
                                var view: View? = trailersAdapter?.getView(i, null, trailerslist)
                                totalHeight += view?.layoutParams?.height ?: 40
                                Log.d("tester",totalHeight.toString()+" ... "+view?.layoutParams?.height.toString())
                                Log.d("tester",totalHeight.toString()+" ... "+view?.measuredHeight.toString())
                            }

                            var params:ViewGroup.LayoutParams = trailerslist.layoutParams

                            params.height = totalHeight + trailerslist.dividerHeight * listTrailers.size

                            trailers_films.layoutParams.height += totalHeight
                            trailers_films.requestLayout()
                            trailerslist.layoutParams = params
                            trailerslist.requestLayout()

                            trailerslist.setOnItemClickListener { parent, view, position, id ->
                                val mTrailerIntent = Intent(
                                    Intent.ACTION_VIEW,
                                    Uri.parse("http://www.youtube.com/watch?v=" + listTrailers[position].key)
                                )
                                startActivity(mTrailerIntent)
                            }
                        }
                    }

                    override fun onFailure(call: Call<TrailersList>, t: Throwable) {
                        Log.d("PLAYERCAT","Failure")
                        t.printStackTrace()
                    }
                })
        }
    }

    fun addToFavorite(){
        val asyncTask = AddMovieAsyncTask(this)
        asyncTask.execute(movie)
    }

    private fun deleteFromFavorite() {
        val asyncTask = DeleteMovieAsyncTask(this)
        asyncTask.execute(movie?.id)
    }

}
