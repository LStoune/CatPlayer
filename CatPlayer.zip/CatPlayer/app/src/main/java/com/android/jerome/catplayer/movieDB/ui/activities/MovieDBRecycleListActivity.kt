package com.android.jerome.catplayer.movieDB.ui.activities

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.DefaultItemAnimator
import android.support.v7.widget.GridLayoutManager
import com.android.jerome.catplayer.R
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import com.android.jerome.catplayer.movieDB.async.GetMoviesAsyncTask
import com.android.jerome.catplayer.movieDB.model.Movie
import com.android.jerome.catplayer.movieDB.model.ResultsMovies
import com.android.jerome.catplayer.movieDB.network.MovieAPI
import com.android.jerome.catplayer.movieDB.network.MovieDBService
import com.android.jerome.catplayer.SearchDialogFragment
import com.android.jerome.catplayer.movieDB.ui.adapter.MovieCellsAdapter
import com.android.jerome.catplayer.movieDB.ui.utils.MovieChangeListener
import com.android.jerome.catplayer.movieDB.ui.utils.MovieDBSelection
import com.android.jerome.catplayer.movieDB.ui.utils.ScrollListener
import com.android.jerome.catplayer.SearchListener
import kotlinx.android.synthetic.main.activity_videoslist.*
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class MovieDBRecycleListActivity : AppCompatActivity(), View.OnClickListener,
    SearchListener, MovieChangeListener {
    override fun onMovieRetrieved(movies: ArrayList<Movie>) {
        adapter?.addVideos(movies)
    }

    override fun onClick(v: View?) {
        when(v?.id){
            R.id.recycle_actualize_button -> {
                currentPage = 1
                adapter?.clear()
                when(listSelection){
                    MovieDBSelection.RESEARCH -> {
                        researchQuery(lastQuery,lastQueryMode,currentPage)
                    }
                    MovieDBSelection.FAVORITES -> {
                        loadFavoris()
                    }
                    else ->{
                        loadPage(currentPage)
                    }
                }
            }
            R.id.recycle_search_button -> {
                Log.d("CATPLAYER","recherche")
                showSearchDialog()
            }
        }
    }

    var adapter: MovieCellsAdapter? = null
    var gridLayoutManager: GridLayoutManager? = null

    private var totalPages:Int? = 1
    private var currentPage = 1

    private var lastQuery = ""
    private var lastQueryMode = "movie"

    private var isLoading:Boolean = false
    private var listSelection: MovieDBSelection = MovieDBSelection.TOP_RATED_MOVIES

    private var movieService: MovieDBService? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_videoslist)

        setSupportActionBar(toolbar_recycle)

        supportActionBar?.title = "CatPlayer"
        supportActionBar?.subtitle = getString(R.string.toprated_movies)
        supportActionBar?.elevation = 4.0F

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)
        supportActionBar?.setDisplayUseLogoEnabled(false)

        adapter = MovieCellsAdapter(this)

        gridLayoutManager = GridLayoutManager(this,2)
        video_list.layoutManager = gridLayoutManager
        video_list.itemAnimator = DefaultItemAnimator()

        video_list.adapter = adapter

        gridLayoutManager?.let {
            video_list.addOnScrollListener(object : ScrollListener(it) {
                override fun loadItems() {
                    isLoading = true
                    currentPage += 1
                    when(listSelection){
                        MovieDBSelection.RESEARCH -> {
                            researchQuery(lastQuery,lastQueryMode,currentPage)
                        }
                        MovieDBSelection.FAVORITES -> {

                        }
                        else ->{
                            loadPage(currentPage)
                        }
                    }
                }

                override fun isLastPage(): Boolean {
                    return currentPage == totalPages
                }

                override fun isLoading(): Boolean {
                    return isLoading
                }
            })
        }

        movieService = MovieAPI.createRetrofit()

        loadPage(1)

        recycle_search_button.setOnClickListener(this)
        recycle_actualize_button.setOnClickListener(this)

    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu to use in the action bar
        val inflater = menuInflater
        inflater.inflate(R.menu.toolbar, menu)
        return super.onCreateOptionsMenu(menu)
    }

    fun loadPage(page:Int = 1){
        movieService = MovieAPI.createRetrofit()
        var sel1 = "movie"
        var sel2 = "top_rated"

        when(this.listSelection) {
            MovieDBSelection.TOP_RATED_MOVIES -> {sel1 = "movie";sel2 = "top_rated"}
            MovieDBSelection.POPULAR_MOVIES -> {sel1 = "movie";sel2 = "popular"}
            MovieDBSelection.UPCOMING_MOVIES -> {sel1 = "movie";sel2 = "upcoming"}
            MovieDBSelection.NOW_PLAYING_MOVIES -> {sel1 = "movie";sel2 = "now_playing"}
            MovieDBSelection.TOP_RATED_TV_SHOWS -> {sel1 = "tv";sel2 = "top_rated"}
            MovieDBSelection.POPULAR_TV_SHOWS -> {sel1 = "tv";sel2 = "popular"}
            MovieDBSelection.ON_THE_AIR_TV_SHOWS -> {sel1 = "tv";sel2 = "on_the_air"}
            MovieDBSelection.AIRING_TODAY_TV_SHOWS -> {sel1 = "tv";sel2 = "airing_today"}
        }

        movieService?.getMovies(sel1,sel2,getString(R.string.apikey),getString(R.string.lang),page)
            ?.enqueue(object : Callback<ResultsMovies> {
                override fun onResponse(call: Call<ResultsMovies>, response: Response<ResultsMovies>) {
                    Log.d("PLAYERCAT", "Success")
                    Log.d("PLAYERCAT", response.code().toString())
                    Log.d("PLAYERCAT", response.raw().request().url().toString())
                    isLoading = false

                    if (response == null) Log.d("PLAYERCAT", "null") else Log.d("PLAYERCAT", "pas null")
                    if (response.isSuccessful) Log.d("PLAYERCAT", "successful") else Log.d("PLAYERCAT", "pas successful")

                    if(currentPage == 1){
                        adapter?.clear()
                    }
                    if(response != null && response.isSuccessful) {
                        totalPages = response.body().totalPages
                        var listMovies = response.body().results
                        Log.d("PLAYERCAT", listMovies.size.toString())
                        adapter?.addVideos(listMovies)

                    }
                }

                override fun onFailure(call: Call<ResultsMovies>, t: Throwable) {
                    isLoading = false
                    Log.d("PLAYERCAT","Failure")
                    t.printStackTrace()
                }
            })
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if(item.itemId == android.R.id.home){
            finish()
            return true
        }
        currentPage = 1
        adapter?.clear()
        when (item.itemId) {
            R.id.menu_toprated -> {
                listSelection = MovieDBSelection.TOP_RATED_MOVIES
                supportActionBar?.subtitle = getString(R.string.toprated_movies)
                loadPage()
                return true
            }
            R.id.menu_popular -> {
                listSelection = MovieDBSelection.POPULAR_MOVIES
                supportActionBar?.subtitle = getString(R.string.popular_movies)
                loadPage()
                return true
            }
            R.id.menu_nowplaying -> {
                listSelection = MovieDBSelection.NOW_PLAYING_MOVIES
                supportActionBar?.subtitle = getString(R.string.nowplaying_movies)
                loadPage()
                return true
            }
            R.id.menu_upcoming -> {
                listSelection = MovieDBSelection.UPCOMING_MOVIES
                supportActionBar?.subtitle = getString(R.string.upcoming_movies)
                loadPage()
                return true
            }
            R.id.menu_toprated_tv -> {
                listSelection = MovieDBSelection.TOP_RATED_TV_SHOWS
                supportActionBar?.subtitle = getString(R.string.toprated_tv)
                loadPage()
                return true
            }
            R.id.menu_popular_tv -> {
                listSelection = MovieDBSelection.POPULAR_TV_SHOWS
                supportActionBar?.subtitle = getString(R.string.popular_tv)
                loadPage()
                return true
            }
            R.id.menu_on_air_tv -> {
                listSelection = MovieDBSelection.ON_THE_AIR_TV_SHOWS
                supportActionBar?.subtitle = getString(R.string.on_the_air_tv)
                loadPage()
                return true
            }
            R.id.menu_airing_today_tv -> {
                listSelection = MovieDBSelection.AIRING_TODAY_TV_SHOWS
                supportActionBar?.subtitle = getString(R.string.airing_today_tv)
                loadPage()
                return true
            }
            R.id.menu_favorite -> {
                listSelection = MovieDBSelection.FAVORITES
                supportActionBar?.subtitle = getString(R.string.favorite)
                loadFavoris()
                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }

    override fun researchQuery(query:String,tv_or_movie:String,page: Int) {
        Log.d("RESEARCH",query)
        lastQuery = query
        lastQueryMode = tv_or_movie
        movieService = MovieAPI.createRetrofit()
        listSelection = MovieDBSelection.RESEARCH
        movieService?.getResearch(tv_or_movie,getString(R.string.apikey),getString(R.string.lang),query,page)
            ?.enqueue(object : Callback<ResultsMovies> {
                override fun onResponse(call: Call<ResultsMovies>, response: Response<ResultsMovies>) {
                    Log.d("PLAYERCAT", "Success")
                    Log.d("PLAYERCAT", response.code().toString())
                    Log.d("PLAYERCAT", response.raw().request().url().toString())

                    if (response == null) Log.d("PLAYERCAT", "null") else Log.d("PLAYERCAT", "pas null")
                    if (response.isSuccessful) Log.d("PLAYERCAT", "successful") else Log.d("PLAYERCAT", "pas successful")

                    if(page==1){
                        adapter?.clear()
                    }
                    if(response != null && response.isSuccessful) {
                        totalPages = response.body().totalPages
                        currentPage = page
                        var listMovies = response.body().results
                        Log.d("PLAYERCAT", listMovies.size.toString())
                        adapter?.addVideos(listMovies)
                    }
                }

                override fun onFailure(call: Call<ResultsMovies>, t: Throwable) {
                    Log.d("PLAYERCAT","Failure")
                    t.printStackTrace()
                }
            })
    }

    fun showSearchDialog() {

        val fm = supportFragmentManager
        val editNameDialogFragment = SearchDialogFragment().newInstance("Research")
        editNameDialogFragment.show(fm, "fragment_edit_research")

    }

    fun loadFavoris() {
        val asyncTask = GetMoviesAsyncTask(this, this)
        asyncTask.execute()
        currentPage = 1
        totalPages=1
    }

}
