package com.android.jerome.catplayer.movieDB.ui.adapter

import android.content.Context
import android.content.Intent
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import com.android.jerome.catplayer.R
import com.android.jerome.catplayer.movieDB.model.Movie
import com.android.jerome.catplayer.movieDB.ui.activities.MovieActivity
import com.bumptech.glide.Glide
import com.android.jerome.catplayer.movieDB.ui.utils.ScrollListener

class MovieCellsAdapter(val context: Context) : RecyclerView.Adapter<MovieCellsAdapter.ViewHolder>() {

    var itemList:ArrayList<Movie> = ArrayList()

    companion object {
        val URL_MOVIEDB_IMAGES = "https://image.tmdb.org/t/p/w185"
    }
    override fun getItemCount(): Int {
        return itemList.size
    }

    fun addVideos(videos:ArrayList<Movie>?){
        if (videos != null) {
            itemList.addAll(videos)
            notifyDataSetChanged()
        }
    }

    fun clear(){
        itemList.clear()
        notifyDataSetChanged()
    }

    override fun onBindViewHolder(vh: ViewHolder, position: Int) {

        vh.title.text = itemList[position].title

        Glide.with(context)
            .load(MovieCellsAdapter.URL_MOVIEDB_IMAGES + this.itemList[position].posterPath)
            .centerCrop()
            .placeholder(R.drawable.poster_empty)
            .into(vh.poster)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view =  LayoutInflater.from(context).inflate(R.layout.cardview_videos, parent, false)
        val vh =  ViewHolder(view)
        view.setOnClickListener {view->
            var position = vh.adapterPosition
            if(position != RecyclerView.NO_POSITION){
                val selectedItem = itemList[position]
                val intent = Intent(view.context, MovieActivity::class.java)
                intent.putExtra("MOVIE_EXTRA",selectedItem)
                view.context.startActivity(intent)
            }
        }
        return vh
    }



    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        var poster: ImageView = view?.findViewById(R.id.card_poster) as ImageView
        var title: TextView = view?.findViewById(R.id.card_title) as TextView

    }

}

