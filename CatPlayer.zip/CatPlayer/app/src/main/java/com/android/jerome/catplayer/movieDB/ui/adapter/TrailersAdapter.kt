package com.android.jerome.catplayer.movieDB.ui.adapter

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import com.android.jerome.catplayer.R
import com.android.jerome.catplayer.movieDB.ui.utils.TrailerClickListener
import com.android.jerome.catplayer.movieDB.model.Trailer

class TrailersAdapter : BaseAdapter, TrailerClickListener {

    private var trailers = ArrayList<Trailer>()
    private var context: Context? = null

    constructor(context: Context, trailers: ArrayList<Trailer>?){
        this.context=context
        if(trailers != null) {
            this.trailers.addAll(trailers)
        }
    }

    fun setTrailers(ts:ArrayList<Trailer>){
        trailers.clear()
        this.trailers.addAll(ts)
        Log.d("tester",ts.toString())
        Log.d("tester",trailers.toString())
    }
    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View? {
        val view: View?
        val holder: TrailerHolder

        if (convertView == null) {
            view = LayoutInflater.from(context).inflate(R.layout.trailer, parent, false)
            holder = TrailerHolder(view)
            view.tag = holder
        } else {
            view = convertView
            holder = view.tag as TrailerHolder
        }

        holder.trailer_title.text = trailers[position].name
        holder.trailer_language.text = trailers[position].iso_3166_1+"-"+trailers[position].iso_3166_1
        Log.d("Wesh","ouais")

        return view
    }

    override fun onTrailerClick(trailer: Trailer) {

    }

    override fun getItem(position: Int): Any {
        return trailers[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getCount(): Int {
        return trailers.size
    }

    private class TrailerHolder(view: View?) {
        val youtube: ImageView = view?.findViewById(R.id.youtube_item) as ImageView
        val trailer_title: TextView = view?.findViewById(R.id.trailer_title) as TextView
        val trailer_language: TextView = view?.findViewById(R.id.trailer_language) as TextView
    }

}
