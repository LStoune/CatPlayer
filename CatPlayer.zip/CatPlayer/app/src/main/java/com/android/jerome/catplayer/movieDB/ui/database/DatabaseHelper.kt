package com.android.jerome.catplayer.movieDB.ui.database

import android.arch.persistence.room.Room
import android.content.Context

class DatabaseHelper{

	companion object {
	    var instance: DatabaseHelper?= null

        @JvmStatic
        fun getInstance(context: Context): DatabaseHelper {
			if(instance == null){
				instance =
                        DatabaseHelper(context)
			}
			return instance!!
		}
    }

    constructor(context:Context){
        db = Room.databaseBuilder(context, MovieDatabase::class.java,"my_favorite_videos").build()
    }

	private val db: MovieDatabase


	fun getMovieDao() : MovieDao {
		return db?.movieDao()
	}


}