package com.android.jerome.catplayer.movieDB.ui.database;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;
import com.android.jerome.catplayer.movieDB.model.Movie

@Dao
interface MovieDao {
    @Query("SELECT * FROM Movie")
    fun getAll() : List<Movie>

    @Query("SELECT id FROM Movie")
    fun getIds() : List<Int>

	@Insert(onConflict = OnConflictStrategy.REPLACE)
	fun insert(movie: Movie)

    @Query("DELETE FROM Movie WHERE id = :movieId")
    fun delete(movieId : Int)
}