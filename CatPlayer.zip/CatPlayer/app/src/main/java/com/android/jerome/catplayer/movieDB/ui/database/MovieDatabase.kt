package com.android.jerome.catplayer.movieDB.ui.database;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.RoomDatabase;
import android.arch.persistence.room.TypeConverters
import com.android.jerome.catplayer.movieDB.model.ConvertersInt
import com.android.jerome.catplayer.movieDB.model.ConvertersString
import com.android.jerome.catplayer.movieDB.model.Movie

@Database(entities= [Movie::class], version=1)
@TypeConverters(*[ConvertersInt::class, ConvertersString::class])
abstract class MovieDatabase : RoomDatabase() {
	abstract fun movieDao() : MovieDao
}