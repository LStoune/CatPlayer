package com.android.jerome.catplayer.movieDB.ui.utils

interface GetFavoritesListener {
    fun setOrNotFavorite(ids_favorites:List<Int>)
    fun changeFavorite()
}