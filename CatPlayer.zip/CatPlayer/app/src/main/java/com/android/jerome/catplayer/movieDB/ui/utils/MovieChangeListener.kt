package com.android.jerome.catplayer.movieDB.ui.utils;

import com.android.jerome.catplayer.movieDB.model.Movie

interface MovieChangeListener {

    fun onMovieRetrieved(movies:ArrayList<Movie>);

}
