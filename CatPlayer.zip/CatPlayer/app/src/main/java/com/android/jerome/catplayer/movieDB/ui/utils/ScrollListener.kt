package com.android.jerome.catplayer.movieDB.ui.utils

import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView

abstract class ScrollListener(var layoutManager: LinearLayoutManager) : RecyclerView.OnScrollListener() {
    override fun onScrolled(recyclerView: RecyclerView?, dx: Int, dy: Int) {
        super.onScrolled(recyclerView, dx, dy)
        var visibleCount = layoutManager.childCount
        var totalCount = layoutManager.itemCount
        var firstVisible = layoutManager.findFirstVisibleItemPosition()

        if(!isLoading() && !isLastPage()){
            if((visibleCount+firstVisible)>=totalCount && firstVisible >=0){
                loadItems()
            }
        }
    }

    abstract fun loadItems()

    abstract fun isLastPage(): Boolean

    abstract fun isLoading(): Boolean
}