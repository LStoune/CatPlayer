package com.android.jerome.catplayer.movieDB.ui.utils

import com.android.jerome.catplayer.movieDB.model.Trailer

interface TrailerClickListener {
    fun onTrailerClick(trailer: Trailer)
}