package com.android.jerome.catplayer.videoplayer.activities

import android.content.ComponentName
import android.net.Uri
import android.os.Bundle
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import android.support.v7.app.AppCompatActivity
import android.util.Log
import android.view.KeyEvent
import android.view.MenuItem
import com.android.jerome.catplayer.R
import com.google.android.exoplayer2.ExoPlayerFactory
import com.google.android.exoplayer2.ExoPlayerFactory.newSimpleInstance
import com.google.android.exoplayer2.SimpleExoPlayer
import com.google.android.exoplayer2.extractor.DefaultExtractorsFactory
import com.google.android.exoplayer2.source.ExtractorMediaSource
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector
import com.google.android.exoplayer2.ui.SimpleExoPlayerView
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory
import com.google.android.exoplayer2.util.Util
import kotlinx.android.synthetic.main.exo_playback_control_view.*
import kotlinx.android.synthetic.main.exoplayer.*
import android.view.KeyEvent.KEYCODE_HOME



class ExoPlayerActivity : AppCompatActivity(){
    private var title:String? = null
    private var path:String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.exoplayer)
        title = intent.getStringExtra("title")
        path = intent.getStringExtra("path")

        val trackSelector = DefaultTrackSelector()
        val exoPlayer = ExoPlayerFactory.newSimpleInstance(baseContext,trackSelector)
        ExoPlayerView?.player = exoPlayer

        titleVideo.text = title

        val mediaUri = Uri.parse(path)

        val userAgent = Util.getUserAgent(baseContext, "ExoPlayer")


        val mediaSource = ExtractorMediaSource.Factory(DefaultDataSourceFactory(baseContext,userAgent)).createMediaSource(mediaUri)

        exoPlayer?.prepare(mediaSource)
        exoPlayer?.playWhenReady = true
    }

    override fun onBackPressed() {
        super.onBackPressed()
        ExoPlayerView?.player?.stop()
        ExoPlayerView?.player?.release()
        this.finish()
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when(item?.itemId) {
            android.R.id.home -> {
                ExoPlayerView?.player?.stop()
                ExoPlayerView?.player?.release()
                finish()
                return true
            }
        }
        return false
    }

    override fun onStop() {
        ExoPlayerView?.player?.stop()
        ExoPlayerView?.player?.release()
        this.finish()
        super.onStop()
    }
}