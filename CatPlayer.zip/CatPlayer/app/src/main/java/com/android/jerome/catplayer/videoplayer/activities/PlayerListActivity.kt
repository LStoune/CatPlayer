package com.android.jerome.catplayer.videoplayer.activities

import android.os.Bundle
import android.os.Environment
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.MenuItem
import android.view.View
import com.android.jerome.catplayer.R
import com.android.jerome.catplayer.SearchDialogFragment
import com.android.jerome.catplayer.SearchListener
import com.android.jerome.catplayer.movieDB.ui.utils.MovieDBSelection
import com.android.jerome.catplayer.videoplayer.adapters.VideoCellsAdapter
import com.android.jerome.catplayer.videoplayer.async.LoadVideo
import com.android.jerome.catplayer.videoplayer.model.VideoCells
import com.android.jerome.catplayer.videoplayer.utils.AddViewListener
import com.android.jerome.catplayer.videoplayer.utils.BottomReachedListener
import com.android.jerome.catplayer.videoplayer.utils.MoviesFilesObserver
import com.android.jerome.catplayer.videoplayer.utils.VideoChangeListener
import kotlinx.android.synthetic.main.activity_videoplayerlist.*
import kotlinx.android.synthetic.main.activity_videoslist.*


class PlayerListActivity : AppCompatActivity(), BottomReachedListener, SearchListener, VideoChangeListener, AddViewListener, View.OnClickListener {
    private var directoryFileObserver: MoviesFilesObserver?=null
    private var reload = false
    private var search = ""
    override fun onVideoChangeListener(videoCells: ArrayList<VideoCells>) {
        if (!reload) {
            cardViewList?.clear()
            reload = true
        }
        Log.d("Youpi", "ndfsf" + videoCells.size.toString())
        Log.d("Youpi", "ndfsf" + videoCells.size.toString())
        if (!videoCells.isEmpty()){
            cardViewList?.add(videoCells.last())
            Log.d("Youpi", "ndfsf" + videoCells.size.toString())
            Log.d("Youpi", "ndfsf" + videoCells.size.toString())

            Log.d("Youpi", "ndfsf" + cardViewList.toString())
            Log.d("Youpi", "ndfsf" + adapter.toString())


            adapter?.notifyDataSetChanged()
        }
    }

    private var layoutManager: RecyclerView.LayoutManager? = null
    private var adapter: VideoCellsAdapter? = null
    private var cardViewList: ArrayList<VideoCells>?= ArrayList()

    override fun onAddView() {
        directoryFileObserver?.stopWatching()

        var loader = LoadVideo(this)
        loader.search = search
        loader.execute()
        reload = false
        directoryFileObserver?.startWatching()


    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when(item?.itemId){
            android.R.id.home -> {
                this.finish()
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_videoplayerlist)

        setSupportActionBar(toolbar_playerlist)

        supportActionBar?.title = "CatPlayer"
        supportActionBar?.elevation = 4.0F

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)
        supportActionBar?.setDisplayUseLogoEnabled(false)

        player_search_button.setOnClickListener(this)
        player_actualize_button.setOnClickListener(this)

        layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL,false)
        videoplayer_list.layoutManager = layoutManager

        adapter = VideoCellsAdapter(cardViewList,this,this,videoplayer_list)
        videoplayer_list.adapter = adapter
        directoryFileObserver = MoviesFilesObserver(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES).absolutePath,this)
        directoryFileObserver?.startWatching()

        onAddView()


    }
    override fun onBottomReached() {
        Log.d("YOUPI","YOUPI !!!!!")
        //addView()
    }
    override fun onClick(v: View?) {
        when(v?.id){
            R.id.player_actualize_button -> {
                Log.d("CATPLAYER","actualize")
                onAddView()
            }
            R.id.player_search_button -> {
                Log.d("CATPLAYER","recherche")
                showSearchDialog()
            }
        }
    }

    fun showSearchDialog() {

        val fm = supportFragmentManager
        val editNameDialogFragment = SearchDialogFragment().newInstance("Research")
        editNameDialogFragment.switchToVideoPlayer()
        editNameDialogFragment.show(fm, "fragment_edit_research")

    }

    override fun researchQuery(query: String, tv_or_movie: String, page: Int) {
        search = query
        onAddView()
        search = ""
    }
}
