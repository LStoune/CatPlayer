package com.android.jerome.catplayer.videoplayer.adapters

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.support.v7.widget.RecyclerView
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import com.android.jerome.catplayer.R
import com.android.jerome.catplayer.videoplayer.activities.ExoPlayerActivity
import com.android.jerome.catplayer.videoplayer.utils.BottomReachedListener
import com.android.jerome.catplayer.videoplayer.model.VideoCells
import kotlinx.android.synthetic.main.cardview_videoplayer.view.*

class VideoCellsAdapter(val itemList:ArrayList<VideoCells>?, val context: Context, val listener: BottomReachedListener, val recyclerView: RecyclerView) : RecyclerView.Adapter<VideoCellsAdapter.VideoCellsViewHolder>() {

    override fun getItemCount(): Int {
        return itemList?.size ?: 0
    }



    override fun onBindViewHolder(holder: VideoCellsViewHolder, position: Int) {
        Log.d("YOUHOU",itemList?.get(position)?.toString())
        holder.title.text = itemList?.get(position)?.title
        holder.duration.text = itemList?.get(position)?.duration
        holder.imageView.setImageBitmap(itemList?.get(position)?.image)
        holder.path = itemList?.get(position)?.path
        if (position == 9) {
            listener.onBottomReached()
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VideoCellsViewHolder {
        return VideoCellsViewHolder(LayoutInflater.from(context).inflate(R.layout.cardview_videoplayer, parent, false))
    }



    class VideoCellsViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        var imageView:ImageView = itemView.cell_image
        var title:TextView = itemView.title
        var duration:TextView = itemView.duration
        var path:String? = null

        init {
            itemView.setOnClickListener { v: View  ->
                Log.d(Log.DEBUG.toString(),v.title.text.toString())
                Log.w("OUI",v.context.toString())
                val intent = Intent(v.context, ExoPlayerActivity::class.java)
                var extras = Bundle()
                extras.putString("title",v.title.text.toString())
                extras.putString("path",this.path)

                intent.putExtras(extras)

                v.context.startActivity(intent)

            }
        }

    }

}

