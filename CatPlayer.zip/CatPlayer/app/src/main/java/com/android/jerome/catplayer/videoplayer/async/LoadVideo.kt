package com.android.jerome.catplayer.videoplayer.async

import android.media.MediaMetadataRetriever
import android.os.AsyncTask
import java.io.File
import android.provider.MediaStore
import android.media.ThumbnailUtils
import android.graphics.Bitmap
import android.os.Environment
import android.util.Log
import com.android.jerome.catplayer.videoplayer.model.VideoCells
import com.android.jerome.catplayer.videoplayer.utils.VideoChangeListener


class LoadVideo(var listener: VideoChangeListener) : AsyncTask<Void, Void, ArrayList<VideoCells>>() {
    private var dirPath = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES).path
    private var videoCells:ArrayList<VideoCells> = ArrayList()
    var search = ""
    override fun doInBackground(vararg params: Void?): ArrayList<VideoCells>? {
        File(dirPath).walk().forEach {
            Log.w("path",it.path)

            var retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(it.toString())

                val thumbnail:Bitmap = ThumbnailUtils.createVideoThumbnail(it.toString(),
                        MediaStore.Images.Thumbnails.MINI_KIND)
                var duration=""
                try {
                    var time: String = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                    val timeInmillisec = java.lang.Long.parseLong(time)
                    val millis = timeInmillisec / 1000
                    val hours = millis / 3600
                    val minutes = (millis - hours * 3600) / 60
                    val seconds = millis - (hours * 3600 + minutes * 60)
                    if(!0.equals(hours)) duration += hours.toString()+"h "
                    if(!0.equals(minutes)) duration += minutes.toString() + "min "
                    duration += seconds.toString() + "s"
                }catch (e:Exception){

                }
                Log.d("meuuuuu",duration)
                var title = ""
                    try {
                        title = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
                    }catch (e:Exception) {
                        title = it.path.split("/").last()
                    }
                if(title.contains(search)){
                    videoCells.add(VideoCells(it.toString(), title, duration, thumbnail))
                }

                publishProgress()

                println(thumbnail.toString())
            }catch (e: Exception){
                Log.w(Log.WARN.toString(),it.path)
            }


            retriever.release()




        }
        return videoCells
    }

    override fun onPreExecute() {
        super.onPreExecute()
        // ...
    }

    override fun onProgressUpdate(vararg values: Void?) {
        super.onProgressUpdate(*values)
        listener.onVideoChangeListener(videoCells?:ArrayList())

    }

    override fun onPostExecute(result: ArrayList<VideoCells>?) {
        super.onPostExecute(result)
        //listener.onVideoChangeListener(result?:ArrayList())


    }
}