package com.android.jerome.catplayer.videoplayer.model

import android.graphics.Bitmap
import android.widget.ImageView

data class VideoCells(var path:String,var title:String, var duration: String, var image: Bitmap) {

}