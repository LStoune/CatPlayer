package com.android.jerome.catplayer.videoplayer.utils

interface AddViewListener {
    fun onAddView()
}