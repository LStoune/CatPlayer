package com.android.jerome.catplayer.videoplayer.utils

interface BottomReachedListener {
    fun onBottomReached();
}