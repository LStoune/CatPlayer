package com.android.jerome.catplayer.videoplayer.utils

import android.os.FileObserver
import android.util.Log
import com.android.jerome.catplayer.videoplayer.utils.AddViewListener


class MoviesFilesObserver(path: String,var listener: AddViewListener) : FileObserver(path) {
    private var twice = false


    override fun onEvent(event: Int, path: String?) {
        Log.e("FileObserver: ",event.toString())

        if(event == FileObserver.CREATE && !twice) {

            if (path != null) {
                //Log.e("FileObserver: ",event.toString())
                listener.onAddView()
            }
            twice=!twice
        }
        if(event == FileObserver.DELETE) {

            if (path != null) {
                //Log.e("FileObserver: ",event.toString())
                listener.onAddView()
            }
        }

    }
}