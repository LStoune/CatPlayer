package com.android.jerome.catplayer.videoplayer.utils

import com.android.jerome.catplayer.videoplayer.model.VideoCells

interface VideoChangeListener {
    fun onVideoChangeListener(videoCells: ArrayList<VideoCells>)
}